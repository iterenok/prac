package com.example.laba2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Находим элементы по ID
        editText = findViewById(R.id.editTextText5);
        button = findViewById(R.id.button3);

        // Добавляем обработчик нажатия
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Получаем текст из поля ввода
                String input = editText.getText().toString().trim();

                // Проверка: поле пустое?
                if (input.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Поле пустое! Введите ответ", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Пытаемся преобразовать в число
                try {
                    int answer = Integer.parseInt(input);

                    // Проверка: правильный ответ?
                    if (answer == 4) {
                        // Переход на экран победы
                        Intent intent = new Intent(MainActivity.this, WinActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        // Переход на экран проигрыша
                        Intent intent = new Intent(MainActivity.this, LoseActivity.class);
                        startActivity(intent);
                        finish();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Введите число!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}