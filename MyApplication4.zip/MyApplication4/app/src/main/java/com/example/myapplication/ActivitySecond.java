package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ActivitySecond extends AppCompatActivity {

    private TextView resultText;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        resultText = findViewById(R.id.result_text);
        backButton = findViewById(R.id.btn_back);

        String surname = getIntent().getStringExtra("PARAM_SURNAME");
        String authResult = getIntent().getStringExtra("AUTH_RESULT");

        String fullMessage = authResult + ": " + surname;
        resultText.setText(fullMessage);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}