package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.ActivitySecond;
import com.example.myapplication.R;

public class MainActivity extends AppCompatActivity {

    private EditText emailInput;
    private EditText passwordInput;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        emailInput = findViewById(R.id.input_email);
        passwordInput = findViewById(R.id.input_password);
        loginButton = findViewById(R.id.btn_login);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailInput.getText().toString();
                String password = passwordInput.getText().toString();

                if (email.equals("admin@admin.ru") && password.equals("123")) {
                    Intent intent = new Intent(MainActivity.this, ActivitySecond.class);
                    String surname = getString(R.string.my_surname);
                    String message = getString(R.string.auth_success);
                    intent.putExtra("PARAM_SURNAME", surname);
                    intent.putExtra("AUTH_RESULT", message);
                    startActivity(intent);
                } else {
                    emailInput.setError(getString(R.string.auth_error));
                }
            }
        });
    }
}