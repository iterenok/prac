package com.example.laba17.ui.forgot;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.example.laba17.R;
import com.example.laba17.ui.otp.OTPActivity;

public class ForgotActivity extends AppCompatActivity {

    private EditText etEmail;
    private Button btnSend;
    private ImageView btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot);

        etEmail = findViewById(R.id.etEmail);
        btnSend = findViewById(R.id.btnSend);
        btnBack = findViewById(R.id.btnBack);

        btnSend.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();

            if (email.isEmpty()) {
                Toast.makeText(this, "Введите email", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!email.contains("@") || !email.contains(".")) {
                Toast.makeText(this, "Некорректный email", Toast.LENGTH_SHORT).show();
                return;
            }

            // Диалоговое окно
            new AlertDialog.Builder(this)
                    .setTitle("Код отправлен")
                    .setMessage("Проверьте вашу почту для получения кода")
                    .setPositiveButton("OK", (dialog, which) -> {
                        // Переход на OTP Verification
                        startActivity(new Intent(ForgotActivity.this, OTPActivity.class));
                    })
                    .show();
        });

        btnBack.setOnClickListener(v -> finish());
    }
}