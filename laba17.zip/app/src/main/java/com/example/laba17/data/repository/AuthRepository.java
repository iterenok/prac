package com.example.laba17.data.repository;

import android.os.Handler;
import android.os.Looper;

public class AuthRepository {

    public interface AuthCallback {
        void onSuccess(String message);
        void onError(String error);
    }

    public void signUp(String email, String password, AuthCallback callback) {
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (email.contains("@") && password.length() >= 6) {
                callback.onSuccess("Регистрация успешна");
            } else {
                callback.onError("Неверные данные");
            }
        }, 1000);
    }

    public void signIn(String email, String password, AuthCallback callback) {
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (email.contains("@") && password.length() >= 6) {
                callback.onSuccess("Вход выполнен");
            } else {
                callback.onError("Неверный email или пароль");
            }
        }, 1000);
    }

    public void sendResetCode(String email, AuthCallback callback) {
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (email.contains("@")) {
                callback.onSuccess("Код отправлен");
            } else {
                callback.onError("Неверный email");
            }
        }, 1000);
    }

    public void verifyCode(String code, AuthCallback callback) {
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (code.length() == 6) {
                callback.onSuccess("Код верен");
            } else {
                callback.onError("Неверный код");
            }
        }, 1000);
    }

    public void updatePassword(String password, String captcha, AuthCallback callback) {
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (password.length() >= 8 && captcha.length() > 0) {
                callback.onSuccess("Пароль обновлен");
            } else {
                callback.onError("Проверьте данные");
            }
        }, 1000);
    }
}