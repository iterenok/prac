package com.example.laba17.ui.update;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.laba17.R;
import java.util.Random;

public class UpdateActivity extends AppCompatActivity {

    private EditText etPassword, etConfirmPassword, etCaptcha;
    private TextView tvStrength, tvCaptchaImage;
    private ProgressBar pbStrength;
    private Button btnSave;
    private ImageView ivTogglePassword, ivToggleConfirmPassword;
    private boolean isPasswordVisible = false;
    private boolean isConfirmVisible = false;
    private String currentCaptcha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        etCaptcha = findViewById(R.id.etCaptcha);
        tvStrength = findViewById(R.id.tvStrength);
        pbStrength = findViewById(R.id.pbStrength);
        btnSave = findViewById(R.id.btnSave);
        ivTogglePassword = findViewById(R.id.ivTogglePassword);
        ivToggleConfirmPassword = findViewById(R.id.ivToggleConfirmPassword);
        tvCaptchaImage = findViewById(R.id.tvCaptchaImage);

        // ===== ГЕНЕРАЦИЯ CAPTCHA =====
        generateCaptcha();

        // Нажатие на CAPTCHA — обновить код
        tvCaptchaImage.setOnClickListener(v -> generateCaptcha());

        // ===== ПОКАЗАТЬ/СКРЫТЬ ПАРОЛЬ =====
        ivTogglePassword.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                isPasswordVisible = !isPasswordVisible;
                togglePasswordVisibility(etPassword, ivTogglePassword, isPasswordVisible);
            }
            return true;
        });

        ivToggleConfirmPassword.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                isConfirmVisible = !isConfirmVisible;
                togglePasswordVisibility(etConfirmPassword, ivToggleConfirmPassword, isConfirmVisible);
            }
            return true;
        });

        // ===== ПРОВЕРКА ПАРОЛЯ В РЕАЛЬНОМ ВРЕМЕНИ =====
        etPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String password = s.toString();
                int strength = getPasswordStrength(password);
                updatePasswordStrength(strength);
                validateForm();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        etConfirmPassword.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { validateForm(); }
            @Override public void afterTextChanged(Editable s) {}
        });

        etCaptcha.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { validateForm(); }
            @Override public void afterTextChanged(Editable s) {}
        });

        btnSave.setOnClickListener(v -> {
            if (validateForm()) {
                Toast.makeText(this, "Пароль изменен!", Toast.LENGTH_SHORT).show();
                // Здесь переход на Home
            }
        });
    }

    // ===== ГЕНЕРАЦИЯ СЛУЧАЙНОГО КОДА (4-значное число) =====
    private void generateCaptcha() {
        Random random = new Random();
        int code = 1000 + random.nextInt(9000); // от 1000 до 9999
        currentCaptcha = String.valueOf(code);
        tvCaptchaImage.setText(currentCaptcha);
        etCaptcha.setText(""); // Очищаем поле ввода CAPTCHA
        validateForm();
    }

    // ===== ПОКАЗАТЬ/СКРЫТЬ ПАРОЛЬ =====
    private void togglePasswordVisibility(EditText editText, ImageView imageView, boolean isVisible) {
        if (isVisible) {
            editText.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            imageView.setImageResource(android.R.drawable.ic_menu_view);
        } else {
            editText.setTransformationMethod(PasswordTransformationMethod.getInstance());
            imageView.setImageResource(android.R.drawable.ic_menu_edit);
        }
        editText.setSelection(editText.getText().length());
    }

    // ===== ОЦЕНКА НАДЕЖНОСТИ ПАРОЛЯ =====
    private int getPasswordStrength(String password) {
        int score = 0;
        if (password.length() >= 8) score++;
        if (password.length() >= 12) score++;
        if (password.matches(".*[A-Z].*")) score++;
        if (password.matches(".*[a-z].*")) score++;
        if (password.matches(".*\\d.*")) score++;
        if (password.matches(".*[^a-zA-Z0-9].*")) score++;
        if (score >= 5) return 2;
        if (score >= 3) return 1;
        return 0;
    }

    private void updatePasswordStrength(int strength) {
        String[] levels = {"Слабый", "Средний", "Сильный"};
        int[] colors = {android.R.color.holo_red_dark, android.R.color.holo_orange_dark, android.R.color.holo_green_dark};
        int[] progress = {30, 60, 100};

        tvStrength.setText("Надежность: " + levels[strength]);
        tvStrength.setTextColor(getColor(colors[strength]));
        pbStrength.setProgress(progress[strength]);
    }

    // ===== ВАЛИДАЦИЯ ВСЕХ ПОЛЕЙ =====
    private boolean validateForm() {
        String password = etPassword.getText().toString().trim();
        String confirm = etConfirmPassword.getText().toString().trim();
        String captcha = etCaptcha.getText().toString().trim();

        boolean isValid = password.length() >= 8 &&
                password.equals(confirm) &&
                captcha.equals(currentCaptcha);

        btnSave.setEnabled(isValid);
        return isValid;
    }
}