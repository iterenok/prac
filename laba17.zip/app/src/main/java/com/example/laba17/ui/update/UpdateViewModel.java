package com.example.laba17.ui.update;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.laba17.common.utils.Validator;
import com.example.laba17.data.repository.AuthRepository;
import com.example.laba17.domain.model.Result;

public class UpdateViewModel extends ViewModel {

    private final AuthRepository authRepository = new AuthRepository();
    private final MutableLiveData<Result<String>> updateResult = new MutableLiveData<>();

    public LiveData<Result<String>> getUpdateResult() {
        return updateResult;
    }

    public void updatePassword(String password, String confirmPassword, String captcha) {
        if (!Validator.isValidPassword(password)) {
            updateResult.setValue(Result.error("Пароль должен содержать минимум 8 символов, заглавные и строчные буквы, цифры и спецсимволы"));
            return;
        }
        if (!password.equals(confirmPassword)) {
            updateResult.setValue(Result.error("Пароли не совпадают"));
            return;
        }
        if (captcha.isEmpty()) {
            updateResult.setValue(Result.error("Введите код с картинки"));
            return;
        }

        authRepository.updatePassword(password, captcha, new AuthRepository.AuthCallback() {
            @Override
            public void onSuccess(String message) {
                updateResult.setValue(Result.success(message));
            }

            @Override
            public void onError(String error) {
                updateResult.setValue(Result.error(error));
            }
        });
    }
}