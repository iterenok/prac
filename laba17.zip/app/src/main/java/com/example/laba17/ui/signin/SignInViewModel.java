package com.example.laba17.ui.signin;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.laba17.data.repository.AuthRepository;
import com.example.laba17.domain.model.Result;

public class SignInViewModel extends ViewModel {

    private final AuthRepository authRepository = new AuthRepository();
    private final MutableLiveData<Result<String>> signInResult = new MutableLiveData<>();

    public LiveData<Result<String>> getSignInResult() {
        return signInResult;
    }

    public void signIn(String email, String password) {
        authRepository.signIn(email, password, new AuthRepository.AuthCallback() {
            @Override
            public void onSuccess(String message) {
                signInResult.setValue(Result.success(message));
            }

            @Override
            public void onError(String error) {
                signInResult.setValue(Result.error(error));
            }
        });
    }
}