package com.example.laba17.data.network;

public class SupabaseClient {
    private static final String BASE_URL = "https://your-project.supabase.co/rest/v1/";
    private static final String API_KEY = "your-api-key";
}