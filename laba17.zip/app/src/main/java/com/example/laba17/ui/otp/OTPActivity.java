package com.example.laba17.ui.otp;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.laba17.R;
import com.example.laba17.ui.update.UpdateActivity;

public class OTPActivity extends AppCompatActivity {

    private EditText[] otpInputs = new EditText[6];
    private TextView tvTimer, tvResend;
    private ImageView btnBack;
    private CountDownTimer timer;
    private boolean isTimerRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);

        otpInputs[0] = findViewById(R.id.etOtp1);
        otpInputs[1] = findViewById(R.id.etOtp2);
        otpInputs[2] = findViewById(R.id.etOtp3);
        otpInputs[3] = findViewById(R.id.etOtp4);
        otpInputs[4] = findViewById(R.id.etOtp5);
        otpInputs[5] = findViewById(R.id.etOtp6);
        tvTimer = findViewById(R.id.tvTimer);
        tvResend = findViewById(R.id.tvResend);
        btnBack = findViewById(R.id.btnBack);

        // Автоматический переход между полями
        for (int i = 0; i < otpInputs.length; i++) {
            final int index = i;
            otpInputs[i].addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (s.length() == 1 && index < 5) {
                        otpInputs[index + 1].requestFocus();
                    }
                    if (s.length() == 0 && index > 0) {
                        otpInputs[index - 1].requestFocus();
                    }
                    checkOtpComplete();
                }

                @Override
                public void afterTextChanged(Editable s) {}
            });
        }

        tvResend.setOnClickListener(v -> {
            if (!isTimerRunning) {
                startTimer();
                Toast.makeText(this, "Код отправлен повторно", Toast.LENGTH_SHORT).show();
            }
        });

        btnBack.setOnClickListener(v -> finish());

        startTimer();
    }

    private void checkOtpComplete() {
        StringBuilder code = new StringBuilder();
        for (EditText input : otpInputs) {
            if (input.getText().length() != 1) return;
            code.append(input.getText().toString());
        }

        if (code.toString().equals("123456")) {
            startActivity(new Intent(OTPActivity.this, UpdateActivity.class));
        } else {

            for (EditText input : otpInputs) {
                input.setBackgroundResource(R.drawable.otp_input_error);
            }
            Toast.makeText(this, "Неверный код", Toast.LENGTH_SHORT).show();
        }
    }

    private void startTimer() {
        isTimerRunning = true;
        tvResend.setEnabled(false);
        timer = new CountDownTimer(10000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                tvTimer.setText(String.format("0:%02d", millisUntilFinished / 1000));
            }

            @Override
            public void onFinish() {
                tvTimer.setText("0:00");
                isTimerRunning = false;
                tvResend.setEnabled(true);
            }
        };
        timer.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (timer != null) timer.cancel();
    }
}