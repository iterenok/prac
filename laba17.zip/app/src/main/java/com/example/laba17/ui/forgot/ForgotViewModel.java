package com.example.laba17.ui.forgot;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.laba17.common.utils.Validator;
import com.example.laba17.data.repository.AuthRepository;
import com.example.laba17.domain.model.Result;

public class ForgotViewModel extends ViewModel {

    private final AuthRepository authRepository = new AuthRepository();
    private final MutableLiveData<Result<String>> sendResult = new MutableLiveData<>();

    public LiveData<Result<String>> getSendResult() {
        return sendResult;
    }

    public void sendResetCode(String email) {
        if (!Validator.isValidEmail(email)) {
            sendResult.setValue(Result.error("Некорректный email"));
            return;
        }

        authRepository.sendResetCode(email, new AuthRepository.AuthCallback() {
            @Override
            public void onSuccess(String message) {
                sendResult.setValue(Result.success(message));
            }

            @Override
            public void onError(String error) {
                sendResult.setValue(Result.error(error));
            }
        });
    }
}