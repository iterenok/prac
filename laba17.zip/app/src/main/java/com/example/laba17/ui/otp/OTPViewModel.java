package com.example.laba17.ui.otp;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.laba17.data.repository.AuthRepository;
import com.example.laba17.domain.model.Result;

public class OTPViewModel extends ViewModel {

    private final AuthRepository authRepository = new AuthRepository();
    private final MutableLiveData<Result<String>> verifyResult = new MutableLiveData<>();

    public LiveData<Result<String>> getVerifyResult() {
        return verifyResult;
    }

    public void verifyCode(String code) {
        authRepository.verifyCode(code, new AuthRepository.AuthCallback() {
            @Override
            public void onSuccess(String message) {
                verifyResult.setValue(Result.success(message));
            }

            @Override
            public void onError(String error) {
                verifyResult.setValue(Result.error(error));
            }
        });
    }

    public void resendCode() {

    }
}