package com.example.laba17.ui.signin;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.laba17.R;

public class SignInActivity extends AppCompatActivity {

    private EditText etEmail;
    private EditText etPassword;
    private Button btnSignIn;
    private TextView tvForgot;
    private TextView tvSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnSignIn = findViewById(R.id.btnSignIn);
        tvForgot = findViewById(R.id.tvForgot);
        tvSignUp = findViewById(R.id.tvSignUp);

        btnSignIn.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Заполните все поля", Toast.LENGTH_SHORT).show();
                return;
            }

            // ПРОВЕРКА ПАРОЛЯ
            if (password.length() < 8) {
                Toast.makeText(this, "Пароль должен быть не менее 8 символов", Toast.LENGTH_SHORT).show();
                return;
            }

            // ПРОВЕРКА EMAIL (должен содержать @)
            if (!email.contains("@")) {
                Toast.makeText(this, "Некорректный email", Toast.LENGTH_SHORT).show();
                return;
            }

            Toast.makeText(this, "Вход выполнен", Toast.LENGTH_SHORT).show();
        });

        tvForgot.setOnClickListener(v -> {
            // Переход на ForgotActivity
            startActivity(new android.content.Intent(SignInActivity.this, com.example.laba17.ui.forgot.ForgotActivity.class));
        });

        tvSignUp.setOnClickListener(v -> finish());
    }
}