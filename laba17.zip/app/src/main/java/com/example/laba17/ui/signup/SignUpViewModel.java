package com.example.laba17.ui.signup;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.laba17.common.utils.Validator;
import com.example.laba17.data.repository.AuthRepository;
import com.example.laba17.domain.model.Result;

public class SignUpViewModel extends ViewModel {

    private final AuthRepository authRepository = new AuthRepository();
    private final MutableLiveData<Result<String>> signUpResult = new MutableLiveData<>();

    public LiveData<Result<String>> getSignUpResult() {
        return signUpResult;
    }

    public void signUp(String email, String password, String confirmPassword) {
        if (!Validator.isValidEmail(email)) {
            signUpResult.setValue(Result.error("Некорректный email"));
            return;
        }
        if (!Validator.isValidPassword(password)) {
            signUpResult.setValue(Result.error("Пароль должен содержать минимум 8 символов, заглавные и строчные буквы, цифры и спецсимволы"));
            return;
        }
        if (!password.equals(confirmPassword)) {
            signUpResult.setValue(Result.error("Пароли не совпадают"));
            return;
        }

        authRepository.signUp(email, password, new AuthRepository.AuthCallback() {
            @Override
            public void onSuccess(String message) {
                signUpResult.setValue(Result.success(message));
            }

            @Override
            public void onError(String error) {
                signUpResult.setValue(Result.error(error));
            }
        });
    }
}